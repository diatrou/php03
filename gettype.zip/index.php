<!DOCTYPE html>

<html lang="el-GR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Δοκιμή τύπων μεταβλητών</title>
  <meta name="description" content="Δοκιμή τύπων μεταβλητών.">
  <meta name="author" content="Δημήτριος Ιατρού">

</head>

<body>
	<h1>Δοκιμή τύπων μεταβλητών</h1>
	
	<p><?php
		$testing; // δήλωση χωρίς εκχώρηση
		// $testing = null; // αρχικοποίηση
		echo "<strong>gettype()</strong><br>";
		echo gettype($testing); // null με προειδοποίηση
		echo "<br><strong>var_dump()</strong><br>"; 
		var_dump($testing);
		echo "<br><strong>print_r()</strong><br>";  
		print_r($testing);
	?></p>
		
<!-- Αρχικά, οι παλιότερες εκδόσεις της PHP (πριν από PHP 5.3) δεν εμφάνιζαν προειδοποιήσεις για 
ακαθόριστες μεταβλητές από προεπιλογή. Ωστόσο, από την PHP 5.3 και μετά, οι προειδοποιήσεις για 
ακαθόριστες μεταβλητές είναι ενεργοποιημένες από προεπιλογή. Αυτό έγινε για να βοηθήσει τους 
προγραμματιστές να ανιχνεύουν και να διορθώνουν πιθανά προβλήματα στον κώδικά τους πιο εύκολα.

Αν χρησιμοποιείς παλιότερη έκδοση και δεν βλέπεις την προειδοποίηση, μπορεί να είναι επειδή η ρύθμιση 
error_reporting είναι διαμορφωμένη να μην εμφανίζει τέτοιου είδους μηνύματα. -->

	<p><?php
		$testing = 5;
	?></p>
	
	<p><?php
		$testing = "Πέντε";
	?></p>
	
	<p><?php
		$testing = 5.0;
	?></p>
	
	<p><?php
		$testing = true;
	?></p>
	
</body>
</html>